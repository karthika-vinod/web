<?php
// Array of Indian Cricket Players
$indianPlayers = array(
    "Virat Kohli",
    "Rohit Sharma",
    "Jasprit Bumrah",
    "KL Rahul",
    "Ravindra Jadeja",
    "Shikhar Dhawan",
    "Hardik Pandya",
    "Ajinkya Rahane",
    "Cheteshwar Pujara",
    "Mohammed Shami"
);

// Function to generate HTML table from array
function generateTable($data) {
    $html = '<table border="1">';
    $html .= '<thead><tr><th>Indian Cricket Players</th></tr></thead>';
    $html .= '<tbody>';

    foreach ($data as $player) {
        $html .= '<tr><td>' . $player . '</td></tr>';
    }

    $html .= '</tbody></table>';

    return $html;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Indian Cricket Players</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin: 20px;
        }

        table {
            width: 50%;
            margin: 20px auto;
            border-collapse: collapse;
        }

        th, td {
            padding: 10px;
            border: 1px solid #ddd;
        }

        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <h2>Indian Cricket Players</h2>

    <?php
    // Display the HTML table
    echo generateTable($indianPlayers);
    ?>
</body>
</html>
