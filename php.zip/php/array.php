<?php
$students = array();

echo "Enter names of students ( 'exit' to stop):\n";

while (true) {
    $name = readline("Enter name: ");

    if ($name === 'exit') {
        break;
    }

    $grade = readline("Enter grade for $name: ");
    $students[$name] = $grade;
}

echo "\nOriginal Associative Array:\n";
print_r($students);

// Sort array by values in ascending order
asort($students);
echo "\nSorted Associative Array (Ascending Order by Grade):\n";
print_r($students);

// Sort array by values in descending order
arsort($students);
echo "\nSorted Associative Array (Descending Order by Grade):\n";
print_r($students);
?>
