.box {
    width: 200px;
    height: 100px;
    background-color: red;
    text-align: center;
    padding: 10px;
    margin: 20px;
}

.relative {
    position: relative;
}

.absolute {
    position: absolute;
}
