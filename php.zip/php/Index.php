<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Store</title>
</head>
<body>
    <h2>Add Book</h2>
    <form action="save_book.php" method="post">
        Book Title: <input type="text" name="title" required><br><br>
        Author: <input type="text" name="author" required><br><br>
        Edition: <input type="text" name="edition"><br><br>
        Publisher: <input type="text" name="publisher"><br><br>
        <input type="submit" value="Save">
    </form>

    <hr>

    <h2>Search Book</h2>
    <form action="search_book.php" method="post">
        Search by Author: <input type="text" name="author" required>
        <input type="submit" value="Search">
    </form>
</body>
</html>
