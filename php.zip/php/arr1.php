<?php

$students = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // If the form is submitted, process the input
    $input = isset($_POST['students']) ? $_POST['students'] : '';
    $studentData = explode(',', $input);
    foreach ($studentData as $data) {
        // Explode each student's data into name, age, and grade
        list($name, $age, $grade) = array_map('trim', explode(':', $data));
        // Create an associative array for each student
        $students[] = array('name' => $name, 'age' => $age, 'grade' => $grade);
    }
}

// Function to display the associative array using print_r
function displayAssociativeArray($title, $array) {
    echo "<strong>$title:</strong>\n";
    echo "<pre>";
    print_r($array);
    echo "</pre>";
}

// Sort associative array by a specific key
function sortByKey($array, $key) {
    usort($array, function($a, $b) use ($key) {
        return $a[$key] <=> $b[$key];
    });
    return $array;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Names</title>
   
</head>
<body>

    <form method="post">
        <label for="students">Enter student data (name:age:grade separated by commas): </label>
        <!-- Initialize the input field with specific student data -->
        <input type="text" name="students" id="students" value="Thoma:50:A, Alby:51:B, Karun:41:C, Jonu:23:A" required>
        <button type="submit">Submit</button>
        <button type="button" onclick="sort()">Sort (Ascending)</button>
        <button type="button" onclick="reverseSort()">Sort (Descending)</button>
    </form>

    <?php
    // Display the original associative array
    displayAssociativeArray("Original Array", $students);

    // Sort the associative array by name in ascending order and display it
    $sortedArrayByName = sortByKey($students, 'name');
    displayAssociativeArray("Sorted Array by Name (Ascending Order)", $sortedArrayByName);

    // Sort the associative array by name in descending order and display it
    $reverseSortedArrayByName = array_reverse($sortedArrayByName);
    displayAssociativeArray("Sorted Array by Name (Descending Order)", $reverseSortedArrayByName);
    ?>

    <script>
        // JavaScript functions for sorting (same as before)
        function sort() {
            var input = document.getElementById("students");
            input.value = input.value.split(',').map(function(item) {
                return item.trim();
            }).sort(function(a, b) {
                return a.split(':')[0].localeCompare(b.split(':')[0]);
            }).join(', ');
        }

        function reverseSort() {
            var input = document.getElementById("students");
            input.value = input.value.split(',').map(function(item) {
                return item.trim();
            }).sort(function(a, b) {
                return b.split(':')[0].localeCompare(a.split(':')[0]);
            }).join(', ');
        }
    </script>

</body>
</html>


