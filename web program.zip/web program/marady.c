<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Marady - Tourist Attractions</title>
    <!-- External CSS -->
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
<center> <img src="marady.jpg" width="700" height="450"></center>
        <h1 align="center" style="color: red;">Welcome to Marady</h1>
<nav>
            <ul>
                
                <li><a href="#ABOUT">ABOUT MARADY</a></li>
                <li><a href="PLACES">MAIN PLACES</a></li>
                <li><a href="EDUCATION">EDUCATIONAL ORGANISATIONS</a></li>
                <li><a href="TOURISM">TOURISM</a></li>
                <li><a href="SPIRTUAL">SPIRITUAL VISIT  US</a></li>
            </ul>
        </nav>
 <section id="about">
        <div class="container">
            <h2>ABOUT MARADY</h2>
        <p>Marady is a village in Ernakulam district in the Indian state of Kerala.[1]

Marady Grama Panchayath office is located in South Marady. Areas near to MC Road is Known as East Marady. Areas which is near to Muvattupuzha town is known as North Marady. All remaining areas are known as South Marady which is covered by Muvattupuzha piravam Road.

Major Hindu Religious attractions are Marady Bhagavathy temple ( Marady Kavu), Aruvikkal Devi Temple, Trikka Mahadeva temple and Sree krishna temple.

Major Christian Churches are St. Mary's Jacobite Syrian Church in Kurukkunnapuram, St. George Jacobite Syrian Church in Erattayanikkunnu, Mor Gregorios Jacobite Syrian Church in North Marady, Mount Horeb St. Thomas Jacobite Syrian Church in South Marady and St. George Catholic Church in East Marady.

Marady Grama Panchayath comes under Muvattupuzha assembly constituency, which in turn is a part of Idukki (Lok Sabha constituency).[2]

The Marady Grama Panchayath consists of thirteen wards and the present panchayath president is Sheri O.P. Baby udf .</p>
    </header>
 <section id="about">
        <div class="container">
            <h2>MAIN PLACES</h2>
        <ul>
                
                <li><a href="#EAST MARADY">EAST MARADY</a></li>
                <li><a href="SOUTH MARADY">SOUTH MARADY</a></li>
                <li><a href="NORTH MARADY">NORTH MARADY/a></li>
                     <li><a href="KAYANDU">KAYANADU/a></li>
   </ul>
</body>
</html>
