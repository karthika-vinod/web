<?php
// Function to calculate electricity bill
function calculateElectricityBill($units) {
    // Given tariff rates
    $fixedCharge = 50; // Fixed charge in rupees
    $unitRate = 5; // Rate per unit in rupees

    // Calculate total charge
    $totalCharge = $fixedCharge + ($units * $unitRate);

    return $totalCharge;
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the units consumed from the user input
    $unitsConsumed = isset($_POST["units"]) ? $_POST["units"] : 0;

    // Validate if the input is a positive number
    if (!is_numeric($unitsConsumed) || $unitsConsumed < 0) {
        $errorMessage = "Please enter a valid positive number for units consumed.";
    } else {
        // Calculate the electricity bill
        $electricityBill = calculateElectricityBill($unitsConsumed);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Electricity Bill Calculator</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            text-align: center;
        }

        h2 {
            color: #333;
        }

        form {
            margin-top: 20px;
        }

        label {
            font-weight: bold;
        }

        input {
            padding: 8px;
        }

        button {
            padding: 10px;
            background-color: #4caf50;
            color: white;
            border: none;
            cursor: pointer;
        }

        .result {
            margin-top: 20px;
            padding: 10px;
            background-color: #fff;
            border: 1px solid #ddd;
        }

        .error {
            color: #ff0000;
            font-weight: bold;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <h2>Electricity Bill Calculator</h2>
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <label for="units">Enter Units Consumed:</label>
        <input type="text" name="units" id="units" required>
        <button type="submit">Calculate</button>
    </form>

    <?php if (isset($errorMessage)) : ?>
        <p class="error"><?php echo $errorMessage; ?></p>
    <?php elseif (isset($electricityBill)) : ?>
        <div class="result">
            <p>Units Consumed: <?php echo $unitsConsumed; ?></p>
            <p>Electricity Bill: Rs. <?php echo $electricityBill; ?></p>
        </div>
    <?php endif; ?>
</body>
</html>
