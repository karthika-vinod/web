<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "library";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$author = $_POST['author'];

$sql = "SELECT * FROM books WHERE author LIKE '%$author%'";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<h2>Search Results:</h2>";
    while($row = $result->fetch_assoc()) {
        echo "Title: " . $row["title"]. " - Author: " . $row["author"]. " - Edition: " . $row["edition"]. " - Publisher: " . $row["publisher"]. "<br>";
    }
} else {
    echo "No books found for the author: " . $author;
}

$conn->close();
?>
