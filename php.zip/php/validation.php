<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Registration</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin: 20px;
        }

        form {
            width: 50%;
            margin: 20px auto;
            text-align: left;
        }

        label {
            display: block;
            margin: 10px 0;
        }

        input {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
        }

        button {
            padding: 10px;
            background-color: #4caf50;
            color: white;
            border: none;
            cursor: pointer;
        }

        .error {
            color: #ff0000;
            font-weight: bold;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <h2>User Registration</h2>
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <label for="username">Username:</label>
        <input type="text" name="username" id="username" pattern="[A-Za-z]+" title="Only characters allowed" required>

        <label for="password">Password:</label>
        <input type="password" name="password" id="password" pattern=".{8,}" title="Minimum 8 characters" required>

        <label for="email">Email:</label>
        <input type="email" name="email" id="email" required>

        <label>Choose Courses:</label>
        <input type="checkbox" name="courses[]" value="Math"> Math
        <input type="checkbox" name="courses[]" value="Science"> Science
        <input type="checkbox" name="courses[]" value="English"> English

        <button type="submit" name="register">Register</button>
    </form>

    <?php
    // Check if the form is submitted
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["register"])) {
        // Retrieve form data
        $username = isset($_POST["username"]) ? trim($_POST["username"]) : "";
        $email = isset($_POST["email"]) ? trim($_POST["email"]) : "";
        $password = isset($_POST["password"]) ? $_POST["password"] : "";
        $courses = isset($_POST["courses"]) ? $_POST["courses"] : array();

        // Basic validation
        $errors = array();

        if (empty($username)) {
            $errors[] = "Username is required.";
        } elseif (!preg_match("/^[A-Za-z]+$/", $username)) {
            $errors[] = "Only characters are allowed in the username.";
        }

        if (empty($password)) {
            $errors[] = "Password is required.";
        } elseif (strlen($password) < 8) {
            $errors[] = "Password must be at least 8 characters long.";
        }

        if (empty($email)) {
            $errors[] = "Email is required.";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = "Invalid email format.";
        }

        // Display errors or success message
        if (!empty($errors)) {
            echo '<div class="error">' . implode('<br>', $errors) . '</div>';
        } else {
            echo '<p>Registration successful! Welcome, ' . htmlspecialchars($username) . '!</p>';
            echo '<p>Selected Courses: ' . implode(', ', $courses) . '</p>';
            // Perform additional actions like storing user data in a database
        }
    }
    ?>
</body>
</html>
