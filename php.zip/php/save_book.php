<?php
$host = 'localhost';
$username = 'root';
$password = ''; // if you don't have a password for root
$database = 'library';
$conn = new mysqli($host, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$title = $_POST['title'];
$author = $_POST['author'];
$edition = $_POST['edition'];
$publisher = $_POST['publisher'];

$sql = "INSERT INTO books (Title, Author, Edition, Publisher) VALUES ('$title', '$author', '$edition', '$publisher')";

if ($conn->query($sql) === TRUE) {
    echo "Book saved successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
